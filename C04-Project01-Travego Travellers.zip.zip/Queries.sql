USE travego;

SELECT Gender, COUNT(*) AS PassengerCount 
FROM Passenger 
WHERE Distance >= 600 
GROUP BY Gender;

SELECT MIN(Price) AS MinimumTicketPrice
FROM Price
WHERE Bus_type = 'Sleeper';

SELECT * FROM Passenger 
WHERE Passenger_name LIKE 'S%';

SELECT P.Passenger_name, P.Boarding_City, P.Destination_City, P.Bus_Type, Pr.Price
FROM Passenger as P
JOIN Price as Pr ON P.Bus_Type = Pr.Bus_type AND P.Distance = Pr.Distance;

SELECT Passenger_name, Price 
FROM Passenger AS P 
JOIN Price AS Pr ON P.Bus_Type = Pr.Bus_type AND P.Distance = Pr.Distance
Where P.Distance = 1000 And P.Bus_Type = 'Sitting';


SELECT DISTINCT p1.Passenger_name, p1.Boarding_city as Destination_city, p1.Destination_city as Boardng_city, p1.Bus_type, p2.Price 
FROM passenger p1, price p2 
WHERE Passenger_name = 'Pallavi' and p1.Distance = p2.Distance;

SELECT DISTINCT Distance 
From Passenger 
ORDER BY Distance DESC;


SELECT SUM(Distance) AS TotalDistance
FROM Passenger;

SELECT Passenger_name, (Distance / (SELECT SUM(Distance) FROM Passenger)) * 100 AS DistancePercentage
FROM Passenger;